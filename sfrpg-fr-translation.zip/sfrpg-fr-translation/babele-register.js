Hooks.once('init', () => {
	if(typeof Babele !== 'undefined') {
		Babele.get().register({
			module: 'sfrpg-translation-fr',
			lang: 'fr',
			dir: 'compendium'
		});
	}
});
