Hooks.on('init', () => {
    let locales = ['fr'];
	locales.forEach(l => {
		Babele.get().register({
			module: 'sfrpg-fr-translation',
			lang: l,
			dir: 'compendium'
		});
	});
});
